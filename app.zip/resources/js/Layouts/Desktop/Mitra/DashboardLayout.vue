<template>
    <DesktopLayout>
      <slot></slot>
    </DesktopLayout>
</template>
<script setup>
    import DesktopLayout from '@/Layouts/Partial/Mitra/Desktop/DesktopLayout.vue'
</script>  