<template>
    <admin-layout>
        

    </admin-layout>
</template>

<script setup>
import AdminLayout from '@/Layouts/AdminLayout.vue';

</script>